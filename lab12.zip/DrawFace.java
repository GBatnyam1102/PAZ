import java.awt.event.MouseEvent;

import acm.graphics.GOval;
import acm.program.GraphicsProgram;

public class DrawFace extends GraphicsProgram{
    public void init(){
        addMouseListeners();
    }
    public void mouseMoved(MouseEvent e){
        double mouseX = e.getX();
        double mouseY = e.getY();

        oorchloh(face1.getLeftEye(), face1.getLeftPupil(), mouseX, mouseY);
        oorchloh(face1.getRightEye(), face1.getRightPupil(), mouseX, mouseY);
    }
     private void oorchloh(GOval eye, GOval pupil, double mouseX, double mouseY) {
        double eyeCenterX = eye.getX() + eye.getWidth() / 2;
        double eyeCenterY = eye.getY() + eye.getHeight() / 2;

        double dx = mouseX - eyeCenterX;
        double dy = mouseY - eyeCenterY;
        double distance = Math.sqrt(dx * dx + dy * dy);

        double maxPupilDistance = eye.getWidth() * 0.2;

        double scale = Math.min(1.0, maxPupilDistance / distance);
        double newPupilX = eyeCenterX + dx * scale - pupil.getWidth() / 2;
        double newPupilY = eyeCenterY + dy * scale - pupil.getHeight() / 2;

        pupil.setLocation(newPupilX, newPupilY);
    }
    public void run(){
        double x = 200;
        double y = 200;
        face1 = new GFace(x, y);
        add(face1);
    }
    public static void main(String[] args) {
        new DrawFace().start();
    }
    private GFace face1;
}
