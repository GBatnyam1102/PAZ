import acm.graphics.*;

public class GFace extends GCompound {
    /** Creates a new GFace object with the specified dimensions */
    public GFace(double width, double height) {
        head = new GOval(width, height);
        leftEye = new GOval(EYE_WIDTH * width, EYE_HEIGHT * height);
        rightEye = new GOval(EYE_WIDTH * width, EYE_HEIGHT * height);
        nose = createNose(NOSE_WIDTH * width, NOSE_HEIGHT * height);
        mouth = new GRect(MOUTH_WIDTH * width, MOUTH_HEIGHT * height);
        leye = new GOval(width * EYE, height * EYE);
        leye.setFilled(true);
        reye = new GOval(width * EYE, height * EYE);
        reye.setFilled(true);
        add(head, 100, 100);
        add(leftEye, 0.25 * width - EYE_WIDTH * width / 2 + 100,
                0.25 * height - EYE_HEIGHT * height / 2 + 100);
        add(rightEye, 0.75 * width - EYE_WIDTH * width / 2 + 100,
                0.25 * height - EYE_HEIGHT * height / 2 + 100);
        add(nose, 0.50 * width + 100, 0.50 * height + 100);
        add(mouth, 0.50 * width - MOUTH_WIDTH * width / 2 + 100,
                0.75 * height - MOUTH_HEIGHT * height / 2 + 100);
        add(leye,(0.25 * width - EYE_WIDTH * width / 2 + 100) + (EYE_WIDTH * width) / 3,
                (0.25 * height - EYE_HEIGHT * height / 2 + 100) + (EYE_HEIGHT * height) / 3);
        add(reye, 0.75 * width - EYE_WIDTH * width / 2 + 100 + (EYE_WIDTH * width) / 3,
                0.25 * height - EYE_HEIGHT * height / 2 + 100 + (EYE_HEIGHT * height) / 3);
    }

    /* Creates a triangle for the nose */
    private GPolygon createNose(double width, double height) {
        GPolygon poly = new GPolygon();
        poly.addVertex(0, -height / 2);
        poly.addVertex(width / 2, height / 2);
        poly.addVertex(-width / 2, height / 2);
        return poly;
    }
    public GOval getLeftEye() {
        return leftEye;
    }
    
    public GOval getRightEye() {
        return rightEye;
    }
    
    public GOval getLeftPupil() {
        return leye;
    }
    
    public GOval getRightPupil() {
        return reye;
    }
    /* Constants specifying feature size as a fraction of the head size */
    private static final double EYE_WIDTH = 0.15;
    private static final double EYE_HEIGHT = 0.15;
    private static final double NOSE_WIDTH = 0.15;
    private static final double NOSE_HEIGHT = 0.10;
    private static final double MOUTH_WIDTH = 0.50;
    private static final double MOUTH_HEIGHT = 0.03;
    private static final double EYE = 0.05;
    /* Private instance variables */
    private GOval head;
    private GOval leftEye, rightEye;
    private GPolygon nose;
    private GRect mouth;
    private GOval leye, reye; 
}