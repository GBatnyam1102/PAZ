import java.awt.Color;
import java.awt.event.MouseEvent;

import acm.graphics.GLabel;
import acm.program.GraphicsProgram;
import acm.util.RandomGenerator;

public class LabelProgram extends GraphicsProgram {
    private static final String[] NERS = { "RED", "ORANGE", "YELLOW", "GREEN", "CYAN", "BLUE", "MAGENTA" };
    private static final Color[] UNGU = {
            Color.RED,
            Color.ORANGE,
            Color.YELLOW,
            Color.GREEN,
            Color.CYAN,
            Color.BLUE,
            Color.MAGENTA
    };

    private RandomGenerator regn = new RandomGenerator();
    private GLabel songoh; 

    public void init() {
        addMouseListeners();
    }

    public void run() {
        double x = getWidth();
        double y = getHeight();
        Label_uusgeh(x, y, NERS, UNGU);
    }

    public void mousePressed(MouseEvent e) {
        songoh = getLabelAt(e.getX(), e.getY());
        if (songoh != null) {
            String text = songoh.getLabel();
            int index = getIndexFromText(text);
            if (index != -1) {
                songoh.setColor(UNGU[index]); 
            }
        }
    }

    public void mouseReleased(MouseEvent e) {
        if (songoh != null) {
            Color currentColor = songoh.getColor();
            Color newColor;
            do {
                newColor = UNGU[regn.nextInt(0, UNGU.length - 1)];
            } while (newColor.equals(currentColor)); 
            songoh.setColor(newColor);
        }
    }

    private void Label_uusgeh(double width, double height, String[] ners, Color[] ungu) {
        for (int i = 0; i < ners.length; i++) {
            double x = regn.nextDouble(0, width - 50);
            double y = regn.nextDouble(0, height - 50);
            GLabel label = new GLabel(ners[i]);
            int b = regn.nextInt(0, ungu.length - 1);
            label.setColor(ungu[b]); 
            label.setFont("Serif-20");
            add(label, x, y);
        }
    }

    private GLabel getLabelAt(double x, double y) {
        if (getElementAt(x, y) instanceof GLabel) {
            return (GLabel) getElementAt(x, y);
        }
        return null;
    }

    private int getIndexFromText(String text) {
        for (int i = 0; i < NERS.length; i++) {
            if (NERS[i].equals(text)) {
                return i;
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        new LabelProgram().start();
    }
}
