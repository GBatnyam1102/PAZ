import java.awt.event.MouseEvent;

import acm.graphics.GLabel;
import acm.program.GraphicsProgram;

public class mousetracker extends GraphicsProgram {
    private GLabel label;

    public void init() {
        addMouseListeners();
    }

    public void mouseDragged(MouseEvent e) {
        if (label == null) {
            double x = e.getX();
            double y = e.getY();

            label = new GLabel("(" + x + " , " + y + ")", x, y + 20);
            add(label);
        }
        else{
            removeAll();
            double x = e.getX();
            double y = e.getY();

            label = new GLabel("(" + x + " , " + y + ")", x, y + 20);
            add(label);
        }
    }

    public void mouseMoved(MouseEvent e) {
        if (label == null) {
            double x = e.getX();
            double y = e.getY();

            label = new GLabel("(" + x + " , " + y + ")", x, y + 20);
            add(label);
        }
        else{
            removeAll();
            double x = e.getX();
            double y = e.getY();

            label = new GLabel("(" + x + " , " + y + ")", x, y + 20);
            add(label);
        }

    }

    public static void main(String[] args) {
        new mousetracker().start();

    }
}
