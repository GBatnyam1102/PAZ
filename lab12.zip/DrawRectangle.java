import acm.graphics.*;
import acm.program.*;
import java.awt.event.*;

public class DrawRectangle extends GraphicsProgram {
    public void init() {
        addMouseListeners();
    }

    public void mousePressed(MouseEvent e) {
        if (lastX != startX && lastY != startY) {
            removeAll();
            startX = e.getX();
            startY = e.getY();
            grect = new GRect(startX, startY, 0, 0);
            grect.setFilled(true);
            add(grect);
        }
        else{
            startX = e.getX();
            startY = e.getY();
            grect = new GRect(startX, startY, 0, 0);
            grect.setFilled(true);
            add(grect); 
        }

    }

    public void mouseDragged(MouseEvent e) {
        double x = Math.min(startX, e.getX());
        double y = Math.min(startY, e.getY());
        double width = Math.abs(e.getX() - startX);
        double height = Math.abs(e.getY() - startY);
        grect.setBounds(x, y, width, height);

    }

    public void mouseReleased(MouseEvent e) {
        lastX = e.getX();
        lastY = e.getY();
    }

    public static void main(String[] args) {
        new DrawRectangle().start();
    }

    private GRect grect;
    private double startX, startY;
    private double lastX, lastY;
}
