import acm.gui.IntField;
import acm.gui.TableLayout;
import acm.program.*;
import java.awt.event.*;
import javax.swing.*;

public class LengthConverter extends Program {
    public void init() {
        setLayout(new TableLayout(3, 2));

        ehleh_utga = new IntField(0);
        tugsgul_utga = new IntField(0);

        inp = new JComboBox<>(units);
        outp = new JComboBox<>(units);

        JButton convertButton = new JButton("Convert ->");
        JButton convertButton1 = new JButton("<- Convert");

        add(inp);
        add(outp);
        add(ehleh_utga);
        add(tugsgul_utga);
        add(convertButton);
        add(convertButton1);

        convertButton.addActionListener(this); 
        convertButton1.addActionListener(this); 
    }

    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();

        if (command.equals("<- Convert")) {
            int garalt1 = tugsgul_utga.getValue();
            String garah_utga = (String) inp.getSelectedItem();
            String oroh_utga = (String) outp.getSelectedItem();

            double conversionFactor = getConversionFactor(oroh_utga, garah_utga);
            int result = (int) Math.round(garalt1 * conversionFactor);
            ehleh_utga.setValue(result);
        } else if (command.equals("Convert ->")) {
            int inputValue = ehleh_utga.getValue();
            String oroh_utga = (String) inp.getSelectedItem();
            String garah_utga = (String) outp.getSelectedItem();

            double conversionFactor = getConversionFactor(oroh_utga, garah_utga);
            int result = (int) Math.round(inputValue * conversionFactor);
            tugsgul_utga.setValue(result);
        }
    }

    private double getConversionFactor(String oroh_utga, String garah_utga) {
        double inchesPerUnit = switch (oroh_utga) {
            case "inches" -> 1;
            case "foot" -> 12;
            case "yard" -> 36;
            case "fathom" -> 72;
            case "rod" -> 198;
            case "furlong" -> 7920;
            case "mile" -> 63360;
            default -> 0;
        };

        double inchesPeroutp = switch (garah_utga) {
            case "inches" -> 1;
            case "foot" -> 12;
            case "yard" -> 36;
            case "fathom" -> 72;
            case "rod" -> 198;
            case "furlong" -> 7920;
            case "mile" -> 63360;
            default -> 0;
        };

        return inchesPerUnit / inchesPeroutp;
    }

    public static void main(String[] args) {
        new LengthConverter().start();
    }

    private IntField ehleh_utga;
    private IntField tugsgul_utga;
    private JComboBox<String> inp;
    private JComboBox<String> outp;

    private final String[] units = {"inches", "foot", "yard", "fathom", "rod", "furlong", "mile"};
}
