import acm.graphics.*;
import acm.program.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ex_nine extends GraphicsProgram {
    public void init() {
        setBackground(Color.GRAY);
        add(new JButton("Clear"), SOUTH);

        sizeSlider = new JSlider(MIN_SIZE, MAX_SIZE, INITIAL_SIZE);
        add(new JLabel(" Small"), SOUTH);
        add(sizeSlider, SOUTH);
        add(new JLabel(" Large"), SOUTH);

        initColorChooser();
        add(colorChooser, SOUTH);

        nameField = new JTextField(15);
        nameField.addActionListener(this);
        add(new JLabel("Name:"), SOUTH);
        add(nameField, SOUTH);

        addMouseListeners();
        addActionListeners();
        addKeyListeners();
    }

    private void initColorChooser() {
        colorChooser = new JComboBox<>();
        colorChooser.addItem(new LabeledColor(Color.WHITE, "White"));
        colorChooser.addItem(new LabeledColor(Color.RED, "Red"));
        colorChooser.addItem(new LabeledColor(Color.YELLOW, "Yellow"));
        colorChooser.addItem(new LabeledColor(Color.ORANGE, "Orange"));
        colorChooser.addItem(new LabeledColor(Color.GREEN, "Green"));
        colorChooser.addItem(new LabeledColor(Color.BLUE, "Blue"));
        colorChooser.addItem(new LabeledColor(Color.BLACK, "Black"));
        colorChooser.addItem(new LabeledColor(Color.MAGENTA, "Magenta"));
        colorChooser.setEditable(false);
        colorChooser.setSelectedItem(new LabeledColor(Color.WHITE, "White"));
    }

    private Color getCurrentColor() {
        return ((LabeledColor) colorChooser.getSelectedItem());
    }

    private double getCurrentSize() {
        return sizeSlider.getValue();
    }

    public void mouseClicked(MouseEvent e) {
        GStar star = new GStar(getCurrentSize());
        star.setFilled(true);
        star.setColor(getCurrentColor());
        add(star, e.getX(), e.getY());

        GLabel label = new GLabel(nameField.getText());
        label.setFont(new Font("SansSerif", Font.BOLD, 12));
        label.setColor(getCurrentColor());
        add(label, e.getX() + getCurrentSize(), e.getY());
        
        NamedStar namedStar = new NamedStar(star, label);
        selectedStar = namedStar;
        stars.add(namedStar);
    }

    public void mousePressed(MouseEvent e) {
        lastX = e.getX();
        lastY = e.getY();
        gobj = getElementAt(lastX, lastY);
        if (gobj != null) {
            for (NamedStar star : stars) {
                if (star.star == gobj || star.label == gobj) {
                    selectedStar = star;
                    break;
                }
            }
        }
    }

    public void mouseDragged(MouseEvent e) {
        if (selectedStar != null) {
            double dx = e.getX() - lastX;
            double dy = e.getY() - lastY;
            selectedStar.move(dx, dy);
            lastX = e.getX();
            lastY = e.getY();
        }
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("Clear")) {
            removeAll();
            stars.clear();
            selectedStar = null;
        } else if (e.getSource() == nameField && selectedStar != null) {
            selectedStar.setLabel(nameField.getText());
        }
    }

    public void keyPressed(KeyEvent e) {
        if (selectedStar != null) {
            switch (e.getKeyCode()) {
                case KeyEvent.VK_LEFT:
                    selectedStar.move(-10, 0);
                    break;
                case KeyEvent.VK_RIGHT:
                    selectedStar.move(10, 0);
                    break;
                case KeyEvent.VK_UP:
                    selectedStar.move(0, -10);
                    break;
                case KeyEvent.VK_DOWN:
                    selectedStar.move(0, 10);
                    break;
                case KeyEvent.VK_DELETE:
                    remove(selectedStar.star);
                    remove(selectedStar.label);
                    stars.remove(selectedStar);
                    selectedStar = null;
                    break;
            }
        }
    }

    public static void main(String[] args) {
        new ex_nine().start();
    }

    private static final int MIN_SIZE = 1;
    private static final int MAX_SIZE = 50;
    private static final int INITIAL_SIZE = 16;

    private JTextField nameField;
    private JSlider sizeSlider;
    private JComboBox<LabeledColor> colorChooser;

    private GObject gobj;
    private double lastX, lastY;
    private NamedStar selectedStar;
    private java.util.List<NamedStar> stars = new java.util.ArrayList<>();

    private class NamedStar {
        GStar star;
        GLabel label;

        NamedStar(GStar star, GLabel label) {
            this.star = star;
            this.label = label;
        }

        void move(double dx, double dy) {
            star.move(dx, dy);
            label.move(dx, dy);
        }

        void setLabel(String text) {
            label.setLabel(text);
        }
    }
}
