import acm.program.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.JSlider;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JLabel;

public class DrawStar extends GraphicsProgram {
    public void init() {
        setBackground(Color.GRAY);
        add(new JButton("Clear"), SOUTH);
        sizeSlider = new JSlider(MIN_SIZE, MAX_SIZE, INITIAL_SIZE);
        add(new JLabel(" Small"), SOUTH);
        add(sizeSlider, SOUTH);
        add(new JLabel(" Large"), SOUTH);
        initColorChooser(); 
        add(colorChooser, SOUTH);
        addMouseListeners();
        addActionListeners();
    }

    private void initColorChooser() {
        colorChooser = new JComboBox<>();
        colorChooser.addItem(new LabeledColor(Color.WHITE, "White"));
        colorChooser.addItem(new LabeledColor(Color.RED, "Red"));
        colorChooser.addItem(new LabeledColor(Color.YELLOW, "Yellow"));
        colorChooser.addItem(new LabeledColor(Color.ORANGE, "Orange"));
        colorChooser.addItem(new LabeledColor(Color.GREEN, "Green"));
        colorChooser.addItem(new LabeledColor(Color.BLUE, "Blue"));
        colorChooser.addItem(new LabeledColor(Color.BLACK, "Black"));
        colorChooser.addItem(new LabeledColor(Color.magenta, "magenta"));
        colorChooser.setEditable(false);
        colorChooser.setSelectedItem(new LabeledColor(Color.WHITE, "White")); 
    }
    private Color getCurrentColor() {
        return (Color) colorChooser.getSelectedItem();
    }

    private double getCurrentSize() {
        return sizeSlider.getValue();
    }

    public void mouseClicked(MouseEvent e) {
        GStar star = new GStar(getCurrentSize());
        star.setFilled(true);
        star.setColor(getCurrentColor());
        add(star, e.getX(), e.getY());
    }
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("Clear")) {
            removeAll();
        }
    }
    public static void main(String[] args) {
        new DrawStar().start();
    }
    /* Private constants */
    private static final int MIN_SIZE = 1;
    private static final int MAX_SIZE = 50;
    private static final int INITIAL_SIZE = 16;
    /* Private instance variables */
    private JSlider sizeSlider;
    private JComboBox<LabeledColor> colorChooser; 
}
