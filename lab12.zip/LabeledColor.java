import java.awt.Color;

public class LabeledColor extends Color {
    private final String label; 

    public LabeledColor(Color color, String label) {
        super(color.getRGB());
        this.label = label;
    }

    @Override
    public String toString() {
        return label;
    }
}
