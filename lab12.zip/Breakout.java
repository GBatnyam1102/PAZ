import acm.graphics.*;
import acm.program.*;
import java.awt.*;
import java.awt.event.MouseEvent;

public class Breakout extends GraphicsProgram {
	private GOval bombog;
	private GRect tavtsan;

	public void run() {
		bombog = new GOval(BOMBOG_DIAMETER, BOMBOG_DIAMETER);
		bombog.setFilled(true);
		bombog.setColor(Color.BLACK);
		add(bombog, BOMBOG_EHLEH_BAIRSHIL_X, BOMBOG_EHLEH_BAIRSHIL_Y);

		setSize(delgets_size_x, delgets_size_y);

		double delgetsnii_hemjeeX = getWidth();
		double delgetsnii_hemjeeY = getHeight();
		double toosgo_X = delgetsnii_hemjeeX / 10;
		double toosgo_Y = delgetsnii_hemjeeY / 40;
		tavtsan = new GRect(tavtsan_x, tavtsan_y);
		tavtsan.setFilled(true);
		add(tavtsan, delgetsnii_hemjeeX / 2 - toosgo_X * 2, delgetsnii_hemjeeY * 2 / 3);
		double ehleh_bairshil_Y = 50;
		for (int i = 0; i < NIIT_TOOSGO; i++) {
			double ehleh_bairshil_X = 0;
			for (int j = 0; j < NIIT_TOOSGO; j++) {
				GRect toosgo = new GRect(toosgo_X, toosgo_Y);
				toosgo.setFilled(true);
				switch (i) {
					case 0: case 1: 
					toosgo.setFillColor(ungu[0]);
						break;
					case 2: case 3: 
					toosgo.setFillColor(ungu[1]);
						break;
					case 4: case 5: 
					toosgo.setFillColor(ungu[2]);
						break;
					case 6: case 7: 
					toosgo.setFillColor(ungu[3]);
						break;
					case 8: case 9: 
					toosgo.setFillColor(ungu[4]);
						break;
				}
				add(toosgo, ehleh_bairshil_X, ehleh_bairshil_Y);
				ehleh_bairshil_X += toosgo_X;

			}
			ehleh_bairshil_Y += toosgo_Y;
		}
		addMouseListeners();
		addKeyListeners();
		while (true) {
			bombogHudulguh();
			murguldsun_eseh();
			pause(10);
		}
		
	}

	private void bombogHudulguh() {
		bombog.move(bombogDx, bombogDy);

		if (bombog.getX() <= 0 || bombog.getX() + BOMBOG_DIAMETER >= getWidth()) {
			bombogDx = -bombogDx;
		}
		if (bombog.getY() <= 0) {
			bombogDy = -bombogDy;
		}
		if (bombog.getY() >= getHeight()) {
			ami--;
	
			if (ami <= 0) {
				ami_duusah();
			} else {
				
				bombog_ehleh();
			}
		}
	}
	private void bombog_ehleh() {
		bombog.setLocation(BOMBOG_EHLEH_BAIRSHIL_X, BOMBOG_EHLEH_BAIRSHIL_Y);
		bombogDx = BOMBOG_HURD_X;
		bombogDy = BOMBOG_HURD_Y;
	}
	
	private void ami_duusah() {
		removeAll();  
		GLabel ami_duusahLabel = new GLabel("GG Bro");
		ami_duusahLabel.setFont("Arial-Bold-30");
		add(ami_duusahLabel, getWidth() / 2 - ami_duusahLabel.getWidth() / 2, getHeight() / 2);
	}
	
	
	private GObject getCollidingObject() {
		if (getElementAt(bombog.getX(), bombog.getY()) != null) {
			return getElementAt(bombog.getX(), bombog.getY());
		}
		if (getElementAt(bombog.getX() + BOMBOG_DIAMETER, bombog.getY()) != null) {
			return getElementAt(bombog.getX() + BOMBOG_DIAMETER, bombog.getY());
		}
		if (getElementAt(bombog.getX(), bombog.getY() + BOMBOG_DIAMETER) != null) {
			return getElementAt(bombog.getX(), bombog.getY() + BOMBOG_DIAMETER);
		}
		if (getElementAt(bombog.getX() + BOMBOG_DIAMETER, bombog.getY() + BOMBOG_DIAMETER) != null) {
			return getElementAt(bombog.getX() + BOMBOG_DIAMETER, bombog.getY() + BOMBOG_DIAMETER);
		}
		return null;
	}

	private void murguldsun_eseh() {
		GObject collider = getCollidingObject();
		if (collider == tavtsan) {
			bombogDy = -bombogDy;
		} else if (collider != null && collider != tavtsan) {
			remove(collider);
			bombogDy = -bombogDy;
		}
	}

	public void mouseMoved(MouseEvent e) {
		double mouseX = e.getX();
		double newX = Math.min(Math.max(0, mouseX - TAVTSAN_URT / 2), getWidth() - TAVTSAN_URT);
		tavtsan.setLocation(newX, tavtsan.getY());
	}

	public static void main(String[] args) {
		new Breakout().start();
	}

	public static int NIIT_TOOSGO = 10;
	public static int delgets_size_x = 500;
	public static int delgets_size_y = 1000;
	public static int tavtsan_x = 200;
	public static int tavtsan_y = 30;
	private static final double BOMBOG_DIAMETER = 20;
	private static final double BOMBOG_EHLEH_BAIRSHIL_X = 250;
	private static final double BOMBOG_EHLEH_BAIRSHIL_Y = 300;
	private double bombogDx = BOMBOG_HURD_X;
	private double bombogDy = BOMBOG_HURD_Y;
	private static final double BOMBOG_HURD_X = 3;
	private static final double BOMBOG_HURD_Y = 3;
	private static final double TAVTSAN_URT = 100;
	private static int ami = 3;
	public static Color ungu[] = {
			Color.RED,
			Color.ORANGE,
			Color.YELLOW,
			Color.GREEN,
			Color.CYAN
	};
}
