import acm.graphics.*;
import acm.program.*;

import java.awt.Color;
import java.awt.event.*;
import javax.swing.*;

public class simpleDraw extends GraphicsProgram {
    private GObject r_object;
    private String ner_songoh = "";

    public void init() {
        addMouseListeners();
        setupButtons(); 
    }

    private void setupButtons() {
        String[] ners = { "Rect", "Rectun", "OvalFill", "Oval", "Line" };
        for (String name : ners) {
            JButton button = new JButton(name);
            button.addActionListener(this);
            add(button, WEST);
        }
    }

    public void actionPerformed(ActionEvent e) {
        ner_songoh = e.getActionCommand();
    }

    public void mousePressed(MouseEvent e) {
        startX = e.getX();
        startY = e.getY();
        createShape(startX, startY);
        if (r_object != null) {
            add(r_object);
        }
    }

    public void mouseDragged(MouseEvent e) {
        if (r_object != null) {
            double x = Math.min(startX, e.getX());
            double y = Math.min(startY, e.getY());
            double width = Math.abs(e.getX() - startX);
            double height = Math.abs(e.getY() - startY);

            if (r_object instanceof GRect || r_object instanceof GOval) {
                r_object.setLocation(x, y);
                ((GResizable) r_object).setSize(width, height);
            } else if (r_object instanceof GLine) {
                ((GLine) r_object).setEndPoint(e.getX(), e.getY());
            }
        }
    }

    private void createShape(double x, double y) {
        switch (ner_songoh) {
            case "Rect":
                r_object = new GRect(x, y, 0, 0);
                ((GRect) r_object).setFilled(false);
                break;
            case "Rectun":
                r_object = new GRect(x, y, 0, 0);
                ((GRect) r_object).setFilled(true);
                ((GRect) r_object).setFillColor(Color.BLUE);
                break;
            case "Oval":
                r_object = new GOval(x, y, 0, 0);
                ((GOval) r_object).setFilled(false);
                break;
            case "OvalFill":
                r_object = new GOval(x, y, 0, 0);
                ((GOval) r_object).setFilled(true);
                ((GOval) r_object).setFillColor(Color.GREEN);
                break;
            case "Line":
                r_object = new GLine(x, y, x, y);
                break;
            default:
                r_object = null;
                break;
        }
    }

    public void mouseClicked(MouseEvent e) {
        if (r_object != null)
            r_object.sendToFront();
    }

    public static void main(String[] args) {
        new simpleDraw().start();
    }

    private double startX, startY;
}
