package ec9;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Random;

public class SlotMachineGraphics extends JFrame {
    private final String[] symbols = {"CHERRY", "LEMON", "ORANGE", "PLUM", "BELL", "BAR"};
    private final Random random = new Random();
    private final JPanel panel;
    private final JLabel[] labels;
    private int money = 50; // Initial money
    private final Object lock = new Object(); // Object to synchronize on

    public SlotMachineGraphics() {
        setTitle("Slot Machine");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);

        panel = new JPanel(new GridLayout(1, 3));
        labels = new JLabel[3];

        for (int i = 0; i < 3; i++) {
            labels[i] = new JLabel();
            panel.add(labels[i]);
        }

        add(panel, BorderLayout.CENTER);

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                startSpinning();
            }
        });
    }

    private void startSpinning() {
        if (money < 1) {
            JOptionPane.showMessageDialog(this, "Sorry, you don't have enough money to spin.", "Not Enough Money", JOptionPane.ERROR_MESSAGE);
            return;
        }

        for (JLabel label : labels) {
            label.setIcon(new ImageIcon("C:\\Users\\tuguuu\\Downloads\\white.jpg"));
        }
        repaint();
        waitForClick();

        String[] result = new String[3];
        for (int i = 0; i < 3; i++) {
            int randomIndex = random.nextInt(6);
            labels[i].setIcon(new ImageIcon("path_to_" + symbols[randomIndex].toLowerCase() + ".jpg"));
            result[i] = symbols[randomIndex];
        }
        calculateWinnings(result);
    }

    private void calculateWinnings(String[] symbols) {
        if (symbols[0].equals("CHERRY") && symbols[1].equals("CHERRY") && symbols[2].equals("CHERRY")) {
            money += 7;
            showWinningMessage("Congratulations! You won $7.");
        } else if (symbols[0].equals("BAR") && symbols[1].equals("BAR") && symbols[2].equals("BAR")) {
            money += 250;
            showWinningMessage("Congratulations! You won $250.");
        } else if (symbols[0].equals("ORANGE") && symbols[1].equals("ORANGE") && (symbols[2].equals("ORANGE") || symbols[2].equals("BAR"))) {
            money += 10;
            showWinningMessage("Congratulations! You won $10.");
        } else if (symbols[0].equals("PLUM") && symbols[1].equals("PLUM") && (symbols[2].equals("PLUM") || symbols[2].equals("BAR"))) {
            money += 14;
            showWinningMessage("Congratulations! You won $14.");
        } else if (symbols[0].equals("BELL") && symbols[1].equals("BELL") && (symbols[2].equals("BELL") || symbols[2].equals("BAR"))) {
            money += 10;
            showWinningMessage("Congratulations! You won $10.");
        } else {
            showWinningMessage("Sorry, you didn't win anything.");
        }

        System.out.println("Current money: $" + money);
    }

    private void showWinningMessage(String message) {
        JOptionPane.showMessageDialog(this, message, "Result", JOptionPane.INFORMATION_MESSAGE);
    }

    private void waitForClick() {
        synchronized (lock) {
            try {
                lock.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private void notifyClick() {
        synchronized (lock) {
            lock.notify();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            SlotMachineGraphics slotMachine = new SlotMachineGraphics();
            slotMachine.setVisible(true);
        });
    }
}

