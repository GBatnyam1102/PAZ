package ec9;
import acm.graphics.*;
import acm.program.*;

public class ex1 extends GraphicsProgram {
    public void run() {
        add(new GImage("C:\\Users\\tuguuu\\Downloads\\apple.png"));
        addCitation("This is apple logo");
    }

    private void addCitation(String text) {
        GLabel label = new GLabel(text);
        label.setFont(CITATION_FONT);
        double x = getWidth() - label.getWidth();
        double y = getHeight() - CITATION_MARGIN + label.getAscent();
        add(label, x, y);
    }

    private static final String CITATION_FONT = "SansSerif-20";
    private static final int CITATION_MARGIN = 23;
    public static final int APPLICATION_WIDTH = 300;
    public static final int APPLICATION_HEIGHT = 300 + CITATION_MARGIN;

    public static void main(String[] args) {
        new ex1().start();
    }
}
