package ec9;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class MonthlyCalendar extends JFrame {

    private static final int DAYS_IN_MONTH = 31;
    private static final int DAY_MONTH_STARTS = 5; // 0 for Sunday, 1 for Monday, ..., 6 for Saturday

    public MonthlyCalendar() {
        setTitle("Monthly Calendar");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 1000);

        // Create a table model to hold the calendar data
        DefaultTableModel model = new DefaultTableModel(new String[]{"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"}, 0);

        // Add rows to the table model
        Object[] rowData = new Object[7]; // 7 columns for the days of the week
        int dayCounter = 1;

        // Fill in the table rows according to the starting day of the month
        for (int row = 0; row < 6; row++) {
            for (int col = 0; col < 7; col++) {
                if (row == 0 && col < DAY_MONTH_STARTS) {
                    rowData[col] = ""; // Fill empty cells before the start day
                } else if (dayCounter <= DAYS_IN_MONTH) {
                    rowData[col] = dayCounter; // Fill the days of the month
                    dayCounter++;
                } else {
                    rowData[col] = ""; // Fill remaining cells with empty string
                }
            }
            model.addRow(rowData);
        }

        // Create the table using the model and customize its appearance
        JTable table = new JTable(model);
        table.setGridColor(Color.BLACK);
        table.setShowGrid(true);
        table.setIntercellSpacing(new Dimension(2, 2));

        // Add the table to the frame
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane);

        setVisible(true);
    }

    public static void main(String[] args) {
        new MonthlyCalendar();
    }
}
