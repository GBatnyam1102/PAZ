package ec9;
import java.awt.*;
import javax.swing.*;

public class ex2 {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Random Color Square");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        JPanel panel = new JPanel() {
            private Color currentColor = Color.BLACK; // Initial color
            
            {
                setPreferredSize(new Dimension(400, 400)); // Adjust dimensions as needed
                setBackground(Color.WHITE); // Set background color
                
                // Create a timer to change color randomly every 1 second
                Timer timer = new Timer(1000, e -> {
                    currentColor = nextColor(); // Generate a random color
                    repaint(); // Redraw the panel with the new color
                });
                timer.start(); // Start the timer
            }
            
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Draw a square in the middle of the panel with the current color
                g.setColor(currentColor);
                int squareSize = 100; // Adjust square size as needed
                int x = (getWidth() - squareSize) / 2;
                int y = (getHeight() - squareSize) / 2;
                g.fillRect(x, y, squareSize, squareSize);
            }
            
            // Method to generate a random color
            private Color nextColor() {
                // Generate random values for red, green, and blue components
                int red = (int) (Math.random() * 256);
                int green = (int) (Math.random() * 256);
                int blue = (int) (Math.random() * 256);
                return new Color(red, green, blue);
            }
        };
        
        frame.add(panel);
        frame.pack();
        frame.setLocationRelativeTo(null); // Center the frame
        frame.setVisible(true);
    }
}
