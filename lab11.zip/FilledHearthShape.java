package ec9;
import javax.swing.*;
import java.awt.*;

public class FilledHearthShape extends JPanel {

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        int squareSize = 200; // Adjust the size of the heart shape here
        int squareX = (getWidth() - squareSize) / 2;
        int squareY = (getHeight() - squareSize) / 2;

        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(Color.RED);

        int radius = squareSize / 2;

        // Fill left semicircle
        g2d.fillArc(squareX, squareY, radius, radius, 0, 180);

        // Fill right semicircle
        g2d.fillArc(squareX + radius, squareY, radius, radius, 0, 180);

        // Create and fill the triangle part of the heart
        int[] xPoints = {squareX, squareX + squareSize / 2, squareX + squareSize};
        int[] yPoints = {squareY + radius / 2, squareY + 2 * radius, squareY + radius / 2};
        g2d.fillPolygon(xPoints, yPoints, 3);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Filled Heart Shape");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        FilledHearthShape heartShape = new FilledHearthShape();
        frame.add(heartShape);
        frame.setSize(400, 400);
        frame.setVisible(true);
    }
}
