package ec9;
import javax.swing.*;
import java.awt.*;

public class PieSlices extends JPanel {

    private static final int WIDTH = 400;
    private static final int HEIGHT = 400;
    private static final int N_PIECES = 6; // Number of pie slices

    public PieSlices() {
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        int startAngle = 0;
        int arcAngle = 360 / N_PIECES;

        for (int i = 0; i < N_PIECES; i++) {
            g2d.setColor(Color.BLACK);
            g2d.fillArc(50, 50, WIDTH - 100, HEIGHT - 100, startAngle, arcAngle);
            g2d.setColor(Color.ORANGE);
            g2d.fillArc(50, 50, WIDTH - 99, HEIGHT - 99, startAngle-1, arcAngle-1);


            startAngle += arcAngle;
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Pie Slices");
        PieSlices pie = new PieSlices();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(pie);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
