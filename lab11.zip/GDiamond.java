package ec9;
import acm.graphics.*;

public class GDiamond extends GPolygon {
    public GDiamond(int x, int y, int width, int height) {
        int[] xPoints = { x + width / 2, x + width, x + width / 2, x };
        int[] yPoints = { y, y + height / 2, y + height, y + height / 2 };

        for (int i = 0; i < xPoints.length; i++) {
            addVertex(xPoints[i], yPoints[i]);
        }
        addVertex(xPoints[0], yPoints[0]);
    }
}