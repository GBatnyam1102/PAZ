package ec9;
import javax.swing.*;
import java.awt.*;
import java.util.*;

public class ColoredLabels {
    public static void main(String[] args) {
        String[] colors = {"RED", "ORANGE", "YELLOW", "GREEN", "CYAN", "BLUE", "MAGENTA"};
        JFrame frame = new JFrame("Colored Labels");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridLayout(0, 1)); // Vertical layout for labels
        
        for (String color : colors) {
            JLabel label = new JLabel(getDifferentColorName(color));
            label.setForeground(getColorFromString(color));
            frame.add(label);
        }
        
        frame.pack();
        frame.setLocationRelativeTo(null); // Center the frame
        frame.setVisible(true);
    }
    
    // Method to get a random color different from the given color
    private static String getDifferentColorName(String currentColor) {
        String[] colors = {"RED", "ORANGE", "YELLOW", "GREEN", "CYAN", "BLUE", "MAGENTA"};
        Random random = new Random();
        String randomColor = currentColor;
        while (randomColor.equals(currentColor)) {
            randomColor = colors[random.nextInt(colors.length)];
        }
        return randomColor;
    }
    
    // Method to convert color names to Color objects
    private static Color getColorFromString(String colorName) {
        try {
            return (Color) Color.class.getField(colorName.toUpperCase()).get(null);
        } catch (Exception e) {
            e.printStackTrace();
            return Color.BLACK;
        }
    }
}
