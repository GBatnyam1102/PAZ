package ec9;
import acm.graphics.*;

public class GTrapezoid extends GPolygon {
    public GTrapezoid(int x, int y, int width, int height, int topWidth) {
        int[] xPoints = { x, x + topWidth, x + width, x + width - topWidth };
        int[] yPoints = { y + height, y, y, y + height };

        for (int i = 0; i < xPoints.length; i++) {
            addVertex(xPoints[i], yPoints[i]);
        }
        // Close the shape by connecting the last point to the first point
        addVertex(xPoints[0], yPoints[0]);
    }
}
