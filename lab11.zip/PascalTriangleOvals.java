package ec9;
import javax.swing.*;
import java.awt.*;

public class PascalTriangleOvals extends JPanel {

    private int N = 10; // Number of lines for Pascal's triangle
    private int[][] pascalTriangle;

    public PascalTriangleOvals() {
        generatePascalTriangle();
    }

    private void generatePascalTriangle() {
        pascalTriangle = new int[N][N];
        for (int line = 0; line < N; line++) {
            for (int i = 0; i <= line; i++) {
                if (i == 0 || i == line) {
                    pascalTriangle[line][i] = 1;
                } else {
                    pascalTriangle[line][i] = pascalTriangle[line - 1][i - 1] + pascalTriangle[line - 1][i];
                }
            }
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        int xSpacing = 50; // Horizontal spacing between ovals
        int ySpacing = 40; // Vertical spacing between ovals
        int ovalWidth = 30; // Oval width
        int ovalHeight = 30; // Oval height

        // Set font for numbers inside ovals
        Font font = new Font("Arial", Font.BOLD, 14);
        g.setFont(font);

        // Set color for ovals and numbers
        g.setColor(Color.BLUE);

        int x = getWidth() / 2 - (N * xSpacing) / 2;
        int y = 50;

        for (int line = 0; line < N; line++) {
            x = getWidth() / 2 - (line * xSpacing) / 2; // Adjust x position for each line

            for (int i = 0; i <= line; i++) {
                g.drawOval(x, y, ovalWidth, ovalHeight);
                g.drawString(String.valueOf(pascalTriangle[line][i]), x + 8, y + 20); // Draw number inside the oval
                x += xSpacing;
            }
            
            y += ySpacing; // Move to the next row
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Pascal's Triangle with Ovals");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        PascalTriangleOvals pascalTriangleOvals = new PascalTriangleOvals();
        frame.add(pascalTriangleOvals);
        frame.setSize(600, 400);
        frame.setVisible(true);
    }
}
