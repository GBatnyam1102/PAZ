package ec9;
import acm.graphics.*;
import acm.program.*;
import java.awt.*;

public class QuiltPatterns extends GraphicsProgram {

    public void run() {
        int blockSize = 200; // Adjust block size here

        // Draw Log Cabin Block
        QuiltBlock logCabinBlock = new LogCabinBlock(blockSize);
        logCabinBlock.setLocation(50, 50);
        add(logCabinBlock);

        // Draw Nested Square Block
        QuiltBlock nestedSquareBlock = new NestedSquareBlock(blockSize);
        nestedSquareBlock.setLocation(300, 50);
        add(nestedSquareBlock);

        // Draw I Love Java Block
        QuiltBlock iLoveJavaBlock = new ILoveJavaBlock(blockSize);
        iLoveJavaBlock.setLocation(550, 50);
        add(iLoveJavaBlock);
    }

    abstract class QuiltBlock extends GCompound {
        protected int blockSize;

        public QuiltBlock(int blockSize) {
            this.blockSize = blockSize;
        }

        public abstract void drawPattern();
    }

    class LogCabinBlock extends QuiltBlock {
        public LogCabinBlock(int blockSize) {
            super(blockSize);
            drawPattern();
        }

        public void drawPattern() {
            for (int i = 0; i < 4; i++) {
                GRect frame = new GRect(blockSize, blockSize);
                frame.setColor(Color.GREEN);
                frame.setFilled(true);
                add(frame, 0, 0);
                blockSize -= 20;
            }
        }
    }

    class NestedSquareBlock extends QuiltBlock {
        public NestedSquareBlock(int blockSize) {
            super(blockSize);
            drawPattern();
        }

        public void drawPattern() {
            Color[] colors = {Color.BLUE, Color.PINK};

            for (int i = 0; i < 5; i++) {
                GRect square = new GRect(blockSize, blockSize);
                square.setColor(colors[i % 2]);
                square.setFilled(true);
                add(square, (i * blockSize) / 2, (i * blockSize) / 2);
                blockSize -= 40;
            }
        }
    }

    class ILoveJavaBlock extends QuiltBlock {
        public ILoveJavaBlock(int blockSize) {
            super(blockSize);
            drawPattern();
        }

        public void drawPattern() {
            GRect frame = new GRect(blockSize, blockSize);
            frame.setColor(Color.MAGENTA);
            frame.setFilled(true);
            add(frame, 0, 0);

            String text = "I Love Java";
            String[] words = text.split(" ");
            int fontSize = 20;
            int x = blockSize / 2 - fontSize * 4;
            int y = blockSize / 2;

            for (String word : words) {
                GLabel label = new GLabel(word);
                label.setColor(Color.WHITE);
                label.setFont(new Font("Arial", Font.BOLD, fontSize));
                add(label, x, y);
                x += fontSize * word.length() + 10;
            }

            GHeart heart = new GHeart(blockSize * 0.6);
            heart.setFilled(true);
            heart.setColor(Color.RED);
            add(heart, blockSize * 0.2, blockSize * 0.2);
        }
    }

    public class GHeart extends GPolygon {
        public GHeart(double size) {
            double x = size / 2;
            double y = 0;

            double[] xPoints = { x, x + size / 4, x + size / 2, x + size / 4 };
            double[] yPoints = { y + size / 2, y + size, y + size / 2, y };

            addVertex(x, y);
            for (int i = 0; i < xPoints.length; i++) {
                addEdge(xPoints[i], yPoints[i]);
            }
        }
    }
}
