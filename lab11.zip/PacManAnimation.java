package ec9;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PacManAnimation extends JPanel implements ActionListener {
    private int pacmanX = 0, pacmanY = 250; // Initial position of PacMan
    private double angle = 0;
    private boolean mouthOpening = true; // Flag for mouth opening/closing animation
    private Timer timer;

    public PacManAnimation() {
        timer = new Timer(20, this); // Timer to control animation speed
        timer.start();
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        // Set background color
        g2d.setColor(Color.BLACK);
        g2d.fillRect(0, 0, getWidth(), getHeight());

        // Set PacMan color
        g2d.setColor(Color.YELLOW);

        // Draw PacMan as an arc
        g2d.fillArc(pacmanX, pacmanY, 100, 100, (int) (angle * 180 / Math.PI), (int) (360 - angle * 360 / Math.PI));

        // Update angle for mouth opening/closing animation
        if (mouthOpening) {
            angle += 0.1;
            if (angle >= 1.2) {
                mouthOpening = false;
            }
        } else {
            angle -= 0.1;
            if (angle <= 0) {
                mouthOpening = true;
            }
        }

        // Update PacMan's position to move from left to right
        pacmanX += 1;

        // Reset PacMan's position when it reaches the right edge of the window
        if (pacmanX > getWidth()) {
            pacmanX = -100;
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("PacMan Animation");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);

        PacManAnimation pacManAnimation = new PacManAnimation();
        frame.add(pacManAnimation);
        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        repaint(); // Redraw the PacMan
    }
}
